export class Account {
    accId:number;
    custName:string;
    balance:number;
}
