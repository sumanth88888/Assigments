package com.cg.exception;

public class AccountException extends Exception {

	public AccountException(String message) {
		super(message);
	}

	
}
